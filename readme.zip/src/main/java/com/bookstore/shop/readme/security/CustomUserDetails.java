package com.bookstore.shop.readme.security;

import com.bookstore.shop.readme.domain.MemberRole;
import com.bookstore.shop.readme.domain.MemberStatus;
import lombok.Getter;
import org.springframework.security.core.userdetails.UserDetails;

@Getter
public class CustomUserDetails implements UserDetails {

    private final Long         memberId;
    private final String       email;
    private final String       password;
    private final MemberRole memberRole;
    private final MemberStatus memberStatus;

    

}
